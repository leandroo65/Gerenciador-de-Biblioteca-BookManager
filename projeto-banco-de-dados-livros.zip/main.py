import sqlite3
import tkinter as tk
from tkinter import messagebox, Toplevel, Listbox, Scrollbar

# Cria uma conexão com o banco de dados (ou cria um novo se não existir)
conn = sqlite3.connect('livros.db')
# Cria um cursor para executar comandos SQL
cursor = conn.cursor()

# Cria a tabela livros se ela não existir
cursor.execute('''
CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY,
    titulo TEXT NOT NULL,
    autor TEXT NOT NULL,
    ano INTEGER NOT NULL
)
''')

# Função para adicionar um livro
def adicionar_livro():
    titulo = entry_titulo.get()
    autor = entry_autor.get()
    ano = entry_ano.get()

    if titulo and autor and ano:
        cursor.execute('''INSERT INTO livros (titulo, autor, ano) VALUES (?, ?, ?)''', (titulo, autor, ano))
        conn.commit()
        messagebox.showinfo('Sucesso', 'Livro adicionado com sucesso!')
        entry_titulo.delete(0, tk.END)
        entry_autor.delete(0, tk.END)
        entry_ano.delete(0, tk.END)
        consultar_livros()
    else:
        messagebox.showerror('Erro', 'Por favor, preencha todos os campos.')

# Função para remover um livro
def remover_livro():
    titulo = entry_titulo.get()
    cursor.execute('''SELECT * FROM livros WHERE titulo = ?''', (titulo,))
    livro = cursor.fetchone()
    if livro:
        cursor.execute('''DELETE FROM livros WHERE titulo = ?''', (titulo,))
        conn.commit()
        messagebox.showinfo('Sucesso', 'Livro removido com sucesso!')
        consultar_livros()
    else:
        messagebox.showerror('Erro', 'Livro não encontrado no banco de dados.')

# Função para consultar todos os livros e exibir em uma nova janela
def consultar_livros():
    nova_janela = Toplevel(root)
    nova_janela.title('Livros no Banco de Dados')

    listbox_livros = Listbox(nova_janela, width=50)
    listbox_livros.grid(row=0, column=0, padx=10, pady=10)

    scrollbar = Scrollbar(nova_janela)
    scrollbar.grid(row=0, column=1, sticky='ns')
    listbox_livros.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox_livros.yview)

    cursor.execute('''SELECT titulo, autor, ano FROM livros''')
    livros = cursor.fetchall()
    if livros:
        for livro in livros:
            listbox_livros.insert(tk.END, f'Título: {livro[0]}, Autor: {livro[1]}, Ano: {livro[2]}')
    else:
        listbox_livros.insert(tk.END, 'Nenhum livro encontrado.')

# Configura a janela principal
root = tk.Tk()
root.title('Gerenciador de Livros')

# Labels e entradas de texto
tk.Label(root, text='Título:').grid(row=0, column=0, padx=10, pady=5)
entry_titulo = tk.Entry(root)
entry_titulo.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root, text='Autor:').grid(row=1, column=0, padx=10, pady=5)
entry_autor = tk.Entry(root)
entry_autor.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root, text='Ano:').grid(row=2, column=0, padx=10, pady=5)
entry_ano = tk.Entry(root)
entry_ano.grid(row=2, column=1, padx=10, pady=5)

# Botões
btn_adicionar = tk.Button(root, text='Adicionar Livro', command=adicionar_livro)
btn_adicionar.grid(row=3, column=0, padx=10, pady=5)

btn_remover = tk.Button(root, text='Remover Livro', command=remover_livro)
btn_remover.grid(row=3, column=1, padx=10, pady=5)

btn_consultar = tk.Button(root, text='Consultar Livros', command=consultar_livros)
btn_consultar.grid(row=4, column=0, columnspan=2, padx=10, pady=5)

# Inicializa a janela principal
root.mainloop()

# Fecha a conexão com o banco de dados quando a janela é fechada
conn.close()
